package com.aperturestudios.studytime;

public class SetterParents {

    public SetterParents() {
    }

    private String name;

    public SetterParents(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
