package com.aperturestudios.studytime;

public class SetterTeachers {

    public SetterTeachers() {
    }

    private String name;

    public SetterTeachers(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
