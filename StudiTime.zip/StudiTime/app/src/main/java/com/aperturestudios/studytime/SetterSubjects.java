package com.aperturestudios.studytime;

public class SetterSubjects {

    public SetterSubjects() {
    }

    private String name;

    public SetterSubjects(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
